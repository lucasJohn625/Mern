import React from 'react';
import PersonForm from './components/PersonForm';
function App() {
  return (
    <div className="App">
      <PersonForm/>
    </div>
  );
}
export default App;
